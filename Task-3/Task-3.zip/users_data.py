users_data = {'1': {'name': 'Zahra', 'score': 20, 'birthday': 1970, 'sex': 'm'},
              '2': {'name': 'Fahmy', 'score': 420, 'birthday': 1960, 'sex': 'M'},
              '3': {'name': 'Naghy', 'score': 98, 'birthday': 2019, 'sex': 'f'},
              '4': {'name': 'Somia', 'score': -90, 'birthday': 2010, 'sex': 'f'},
              '5': {'name': 'Elsadiq', 'score': -1, 'birthday': 2012, 'sex': 'M'},
              '6': {'name': 'Rahma', 'score': 9, 'birthday': 1982, 'sex': 'f'},
              '7': {'name': 'Dina', 'score': 89, 'birthday': 1999, 'sex': 'f'},
              '8': {'name': 'Nasser', 'score': 999, 'birthday': 1890, 'sex': 'm'},
              '9': {'name': 'Nirvana', 'score': 'n/a', 'birthday': 1930, 'sex': 'f'}}
